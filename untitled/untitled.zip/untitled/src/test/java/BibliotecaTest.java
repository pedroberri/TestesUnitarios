import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BibliotecaTest {
    private Biblioteca biblioteca;

    @BeforeEach
    public void setUp() {
        biblioteca = new Biblioteca("Biblioteca-1");
    }

    @Test
    public void testGetNome() {
        assertInstanceOf(String.class, biblioteca.getNome());
    }

    @Test
    public void testAdicionarLivro() {
        Livro livroNull = null;
        assertTrue(biblioteca.adicionarLivro(criarLivro()));
        assertFalse(biblioteca.adicionarLivro(livroNull));
    }

    @Test
    public void testRemoverLivro() {
        assertTrue(biblioteca.removerLivro(criarLivro()));
    }

    @Test
    public void testBuscarLivroPorTitulo() {
        // nao sei o que é stream()
    }

    @Test
    public void testBuscarLivrosPorAutor() {
        List<Livro> livros = biblioteca.buscarLivrosPorAutor(criarLivro().getAutor());
        assertInstanceOf(List.class, livros);
        assertInstanceOf(Livro.class, livros.get(0));
    }

    @Test
    public void testBuscarLivrosPorGenero() {
        List<Livro> livros = biblioteca.buscarLivrosPorGenero(criarLivro().getGenero());
        assertInstanceOf(List.class, livros);
        assertInstanceOf(Livro.class, livros.get(0));
    }

    public Livro criarLivro() {
        Livro livro;
        livro = new Livro("Titulo-1", "Autor-1", "Genero-1", 2000);
        return livro;
    }
}
